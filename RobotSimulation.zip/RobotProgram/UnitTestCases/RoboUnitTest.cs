﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace RoboUnitTestCases
{
    [TestClass]
    public class RoboTestCase
    {
        [TestMethod]
        public void StartSimulationTest()
        {
            
        }
    }
}
