﻿using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace TestLibrary
{
    [TestClass]
    public class RoboSimulationTest
    {
        [TestMethod]
        public void StartSimulationTest()
        {
             
        }
    }
}
