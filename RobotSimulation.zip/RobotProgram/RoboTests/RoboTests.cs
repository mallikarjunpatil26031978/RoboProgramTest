﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace RoboTests
{
    [TestClass]
    public class RoboTests
    {
        [TestMethod]
        public void Simulate_Successful()
        {
           
        }
    }
}
