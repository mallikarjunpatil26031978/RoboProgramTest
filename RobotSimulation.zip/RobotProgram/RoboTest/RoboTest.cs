﻿using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace RoboTest
{
    [TestClass]
    public class RoboTest
    {
        [TestMethod]
        public void RoboTest_Successfull()
        {
             
        }
    }
}
