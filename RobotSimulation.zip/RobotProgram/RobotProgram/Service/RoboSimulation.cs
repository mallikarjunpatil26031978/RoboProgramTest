﻿using RobotProgram.Service.Abstraction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace RobotProgram.Service
{
    public  class RoboSimulation : Abstraction.IRoboSimulation
    {
        private static List<string> LEFT_DIRECTIONS = new List<string> { "NORTH", "WEST", "SOUTH", "EAST" };
        private static List<string> RIGHT_DIRECTIONS= new List<string> { "NORTH", "WEST", "SOUTH", "EAST" };
        public void Simulate()
        {
            try
            { 
            Console.WriteLine("Enter start position ");
            string str = Console.ReadLine();
                if (str.StartsWith("PLACE"))
                {
                    string cons = str.Substring(5);
                    string[] split = cons.Split(",");
                    int startX = int.Parse(split[0].Trim());
                    int startY = int.Parse(split[1].Trim());
                    string direction = split[2].Trim();
                    while (true)
                    {
                        int i;
                        string movement = Console.ReadLine();
                        if (movement.Equals("LEFT"))
                        {
                            i = LEFT_DIRECTIONS.IndexOf(direction);
                            direction = LEFT_DIRECTIONS[i + 1];
                        }
                        else if (movement.Equals("RIGHT"))
                        {
                            i = RIGHT_DIRECTIONS.IndexOf(direction);
                            direction = RIGHT_DIRECTIONS[i + 1];
                        }
                        else if (movement.Equals("MOVE"))
                        {
                            if (direction.Equals("NORTH"))
                            {
                                i = startY + 1;                             
                                startY = i;
                            }
                            else if (direction.Equals("SOUTH"))
                            {
                                i = startY - 1;
                                startY = i;
                            }
                            else if (direction.Equals("EAST"))
                            {
                                i = startX + 1;
                                startX = i;
                            }
                            else if (direction.Equals("WEST"))
                            {
                                i = startX - 1;                               
                                startX = i;
                            }
                        }
                        else if (movement.Equals("REPORT"))
                        {
                            Console.WriteLine("Output: " + startX + "," + startY + "," + direction);
                            break;
                        }
                    }
                }
                else
                {
                    Console.WriteLine("String not in correct format, please try again");
                }
                Console.ReadLine(); 
                }
                catch(Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                
             }

        }
}

