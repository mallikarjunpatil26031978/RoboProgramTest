﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotProgram.Service.Abstraction
{
    public interface IRoboSimulation
    {
        public void Simulate();
    }
}
