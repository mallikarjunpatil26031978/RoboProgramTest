﻿using RobotProgram.Service;
using System;
using System.Collections.Generic;

public class Robot
{  
    public static void Main(string[] args)
    {
        RoboSimulation roboSimulation = new RoboSimulation();
        roboSimulation.Simulate();
    }
}

