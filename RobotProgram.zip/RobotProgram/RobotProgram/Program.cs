﻿using System;
using System.Collections.Generic;

public class RobotProgram
{
    private static List<string> LEFT_DIRECTIONS = new List<string> { "NORTH", "WEST", "SOUTH", "EAST", "NORTH" };
    private static List<string> RIGHT_DIRECTIONS = new List<string> { "NORTH", "EAST", "SOUTH", "WEST", "NORTH" };

    public static void Main(string[] args)
    {
        Console.WriteLine("Enter start position ");
        string str = Console.ReadLine();
        if (str.StartsWith("PLACE"))
        {
            string cons = str.Substring(5);
            string[] split = cons.Split(",");
            int startX = int.Parse(split[0].Trim());
            int startY = int.Parse(split[1].Trim());
            string direction = split[2].Trim();

            while (true)
            {
                string movement = Console.ReadLine();
                if (movement.Equals("LEFT"))
                {
                    int i = LEFT_DIRECTIONS.IndexOf(direction);
                    direction = LEFT_DIRECTIONS[i + 1];
                }
                else if (movement.Equals("RIGHT"))
                {
                    int i = RIGHT_DIRECTIONS.IndexOf(direction);
                    direction = RIGHT_DIRECTIONS[i + 1];
                }
                else if (movement.Equals("MOVE"))
                {
                    if (direction.Equals("NORTH"))
                    {
                        int i = startY + 1;
                        if (i < 5)
                        {
                            startY = i;
                        }
                    }
                    else if (direction.Equals("SOUTH"))
                    {
                        int i = startY - 1;
                        if (i >= 0)
                        {
                            startY = i;
                        }
                    }
                    else if (direction.Equals("EAST"))
                    {
                        int i = startX + 1;
                        if (i < 5)
                        {
                            startX = i;
                        }
                    }
                    else if (direction.Equals("WEST"))
                    {
                        int i = startX - 1;
                        if (i >= 0)
                        {
                            startX = i;
                        }
                    }
                }
                else if (movement.Equals("REPORT"))
                {
                    Console.WriteLine("Output: " + startX + "," + startY + "," + direction);
                    break;
                }
            }
        }
    }
}

